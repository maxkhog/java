package com.samsung.itschool;

public class LoopsTasks {

    public static void main(String[] args) {
        // выводим числа Фибоначи
        System.out.println(factorial(5));

        int i = lastEnemy(new int[]{3, 5, 2});
        System.out.println(i);

        System.out.println(lastEnemy(new int[]{-1, 1, 0, 1, -1}));

    }


    /**
     * Евклидово расстояние между точками n-мерного пространства
     *
     * @param x точка n-мерного пространства
     * @param y точка n-мерного пространства
     * @return расстояние между точками
     * @link http://statistica.ru/glossary/general/evklidovo-rasstoyanie/
     */
    public static double dist(double[] x, double[] y) {
        //todo Определить стартовое значение аккумулятора
        double sum = 0;
        //todo в цикле суммировать в аккумуляторе квадраты разностей координат.
        for (int i = 0; i < x.length; i++) {
            sum = sum + (x[i]-y[i]) * (x[i]-y[i]);
        }
        //todo вернуть квадратный корень накопленной суммы
        return  Math.sqrt(sum);
    }


    /**
     * Числа Фибоначи.
     * Числами Фибоначи называют следующий ряд:
     * 1 1 2 3 5 8 13 21 34 ...
     * Первые два элемента последовательности равняются 1.
     * Последующие элементы вычисляются с помощью суммы двух предыдущих элементов:
     * 1+1 = 2
     * 1+2 = 3
     * 2 + 3 = 5
     * и т.д.
     * <p>
     * Функция возвращает массив, заполненный числами Фибоначи размерности n
     *
     * @param n первых чисел ряда Фибоначи
     * @return массив, содержащий n первых чисел ряда Фибоначи
     */
    public static int[] fibonachi(int n) {
        //todo Определяем массив размерности n
        int[] mas = new int [n];
        //todo первые два элемента равны 1.
        for (int i=0; i<mas.length; i++ )
        {
            if (i == 0) {
                mas[0] = 1;
                continue;
            }
            if (i == 1) {
                mas [1] = 1;
                continue;
            }
            mas [i] = mas [i-2]+mas[i-1];
        }
        //todo с третьего элемента число Фибоначи равно сумме двух предыдущих
        //todo Возвращаем массив mas
        return mas;
    }

    /**
     * Значение многочлена функции
     * f(x) = a0*x^(n-1) + a1*x^(n-2)+ ... + an
     *
     * @param a - вектор параметров
     * @param x - значение аргумента фукнции
     * @return значение f(x)
     */
    public static double f(double a[], double x) {

        //todo заводим аккумулятор для суммы
        double sum=0;
        //todo находим n как длину массива параметров (переменная "a")
        int n=a.length;
        //todo в цикле суммируем по формуле
        for (int i=0;i<a.length;i++){
            sum = sum + a[i]*Math.pow(x,n-i-1);
        }
        //todo возвращаем накопленную сумму
        return sum;
    }

    /**
     * Найти первый корень уравнения на интервалле от min до max c шагом step
     * В случае, если корней нет, возвращаем Double.MAX_VALUE
     *
     * @param a - вектор параметров, задающий многочлен
     * @param min - минимальное значение x, левая граница отрезка
     * @param max - максимальное значение x, правая граница отрезка
     * @param step - шаг, на который мы изменяем x во время перебора
     * @return первый корень уравнения f(x) = 0 в интервале от min до max
     */
    public static double equation(double a[], double min, double max, double step) {
        //todo организовать цикл от min до max с шагом step
        //todo для каждого x вычисляем значение функции f(x)
        //todo проверяем, что |f(x)| ~ 0

        //ПОДСКАЗКА: для вычисления значения f(x) можно испольовать вызов функции f(a,x), например для x = 1.5:
        // double fx = f(a, 1.5);
        for (double i = min; i<max; i++) {
            double fx = f(a, i);
            if (Math.abs(fx)<0.1 ) {
                return i;
            }
        }
        //если на заданном интервале не нашли корней, возвращаем константу Double.MAX_VALUE
        return Double.MAX_VALUE;
        }

        /**
         * Функция возвращает факториал числа
         * @param n - число от которого берется факториал
         * @return факториал числа n
         *
         */
    public static long factorial(int n){
        //todo реализовать с помощью цикла
        if (n == 0) return 1;
        long ret = 1;
        for (int i = 1; i <= n; ++i) {
            ret = ret*i;
        }
        return ret;
        // ПОДСКАЗКА: попробуйте использовать цикл с аккумулятором, по аналогии со суммой чисел.


    }

    /**
     * Космический рейнджер
     * @link http://www.russiancodecup.ru/ru/tasks/round/57/A/
     *
     * Нужно найти индекс элемента массива,
     * значение которого равняется сумме всех остальных элементов массива.
     *
     * @param f - массив сил врагов
     * @return индекс врага с силой равной суммарной силе всех остальных враговвы
     */
    public static int lastEnemy(int[] f){
        int Strongenemy=0;
        for (int i=0; i<f.length;i++) {
        Strongenemy = Strongenemy+f[i];
        }
        for (int i=0; i<f.length;i++) {
            if (Strongenemy/2==f[i]){
                return i;
            }
        }
        return Strongenemy;
    }

    /**
     * Реверс массива. Возвращает массив из элементов, расположенных в обратном порядке.
     * @param arr исходный массив
     * @return массив элементов, расположенных в обратном порядке
     */
    public static int[] reverse(int[] arr){
        int reversapp [] = new int [arr.length];
        for (int i = 0; i<arr.length;i++) {
            reversapp [i] = arr [arr.length-i-1];
        }
        return reversapp;
    }
}
